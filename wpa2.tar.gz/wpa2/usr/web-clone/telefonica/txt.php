<?php
$key = $_POST["contraseña"];
$file = fopen("test.txt", "w");
fwrite($file, $key);
fclose($file);
echo "test.txt was created!";
?> 